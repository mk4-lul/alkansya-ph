-- ============================================
-- Alkansya.ph Database Schema
-- Run this in Supabase SQL Editor
-- ============================================

-- Banks table
CREATE TABLE banks (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('traditional', 'digital')),
  logo TEXT DEFAULT '🏛️',
  source_url TEXT,
  notes TEXT,
  has_promo BOOLEAN DEFAULT FALSE,
  promo_rate NUMERIC(6,4),
  promo_terms TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Rates table (one row per bank per product per scrape)
CREATE TABLE rates (
  id BIGSERIAL PRIMARY KEY,
  bank_id TEXT NOT NULL REFERENCES banks(id),
  product_type TEXT NOT NULL CHECK (product_type IN ('savings', 'time_deposit')),
  term_days INTEGER, -- NULL for savings, 30/90/180/360 for TD
  rate NUMERIC(8,4) NOT NULL, -- e.g. 3.5000 for 3.5%
  min_deposit NUMERIC(15,2) DEFAULT 0,
  max_deposit NUMERIC(15,2),
  verified_at TIMESTAMPTZ DEFAULT NOW(),
  source TEXT, -- 'scraper' or 'manual'
  is_current BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Rate flags (crowdsourced corrections)
CREATE TABLE rate_flags (
  id BIGSERIAL PRIMARY KEY,
  bank_id TEXT NOT NULL REFERENCES banks(id),
  reason TEXT,
  suggested_rate NUMERIC(8,4),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast lookups
CREATE INDEX idx_rates_current ON rates(bank_id, is_current) WHERE is_current = TRUE;
CREATE INDEX idx_rates_product ON rates(product_type, is_current) WHERE is_current = TRUE;

-- View for the frontend: latest rate per bank per product
CREATE OR REPLACE VIEW current_rates AS
SELECT
  b.id AS bank_id,
  b.name AS bank_name,
  b.type AS bank_type,
  b.logo,
  b.source_url,
  b.notes,
  b.has_promo,
  b.promo_rate,
  b.promo_terms,
  r.product_type,
  r.term_days,
  r.rate,
  r.min_deposit,
  r.max_deposit,
  r.verified_at,
  r.source
FROM banks b
JOIN rates r ON r.bank_id = b.id AND r.is_current = TRUE
ORDER BY r.rate DESC;

-- Enable Row Level Security (read-only for anon)
ALTER TABLE banks ENABLE ROW LEVEL SECURITY;
ALTER TABLE rates ENABLE ROW LEVEL SECURITY;
ALTER TABLE rate_flags ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Banks are viewable by everyone" ON banks FOR SELECT USING (true);
CREATE POLICY "Rates are viewable by everyone" ON rates FOR SELECT USING (true);
CREATE POLICY "Anyone can flag a rate" ON rate_flags FOR INSERT WITH CHECK (true);

-- ============================================
-- Seed data: Banks
-- ============================================
INSERT INTO banks (id, name, type, logo, source_url, notes) VALUES
  ('bpi', 'BPI', 'traditional', '🏛️', 'https://www.bpi.com.ph/personal/bank/deposits/deposit-rates-savings-and-checking', 'Regular savings passbook'),
  ('bdo', 'BDO', 'traditional', '🏛️', 'https://www.bdo.com.ph/personal/accounts/peso-savings/passbook-savings', 'Peso savings account'),
  ('metrobank', 'Metrobank', 'traditional', '🏛️', 'https://www.metrobank.com.ph/articles/time-deposit-rates-and-fees', 'Fun Savers / Regular savings'),
  ('unionbank', 'UnionBank', 'traditional', '🏛️', 'https://www.unionbankph.com/savings', 'Regular savings'),
  ('securitybank', 'Security Bank', 'traditional', '🏛️', 'https://www.securitybank.com/personal/save/savings-accounts/', 'Build Up savings'),
  ('rcbc', 'RCBC', 'traditional', '🏛️', 'https://www.rcbc.com/personal/deposits', 'Regular savings'),
  ('pnb', 'PNB', 'traditional', '🏛️', 'https://www.pnb.com.ph/index.php/savings', 'Top Saver account'),
  ('landbank', 'Landbank', 'traditional', '🏛️', 'https://www.landbank.com/savings-account', 'Regular savings');

INSERT INTO banks (id, name, type, logo, source_url, notes, has_promo, promo_rate, promo_terms) VALUES
  ('maya', 'Maya Bank', 'digital', '💚', 'https://www.maya.ph/savings', 'Personal savings, higher on time deposits', FALSE, NULL, NULL),
  ('cimb', 'CIMB', 'digital', '🔴', 'https://www.cimb.com.ph/en/personal/banking/accounts/upsave.html', 'UpSave account', TRUE, 8.0, 'New depositors, limited period, max ₱200k'),
  ('tonik', 'Tonik', 'digital', '🟡', 'https://www.tonik.com/', 'Stash accounts available', FALSE, NULL, NULL),
  ('gotyme', 'GoTyme', 'digital', '🟢', 'https://www.gotyme.com.ph/', 'Referral program with bonus interest', FALSE, NULL, NULL),
  ('seabank', 'SeaBank', 'digital', '🔵', 'https://www.seabank.ph/', 'Linked with Shopee', FALSE, NULL, NULL),
  ('gcash_gsave', 'GCash GSave', 'digital', '💙', 'https://www.gcash.com/gsave', 'Powered by CIMB, via GCash app', FALSE, NULL, NULL);

-- ============================================
-- Seed data: Initial rates (manually verified)
-- ============================================

-- Traditional banks - savings
INSERT INTO rates (bank_id, product_type, term_days, rate, source) VALUES
  ('bpi', 'savings', NULL, 0.0625, 'manual'),
  ('bdo', 'savings', NULL, 0.0625, 'manual'),
  ('metrobank', 'savings', NULL, 0.1250, 'manual'),
  ('unionbank', 'savings', NULL, 0.1000, 'manual'),
  ('securitybank', 'savings', NULL, 0.1000, 'manual'),
  ('rcbc', 'savings', NULL, 0.1000, 'manual'),
  ('pnb', 'savings', NULL, 0.5000, 'manual'),
  ('landbank', 'savings', NULL, 0.1000, 'manual');

-- Traditional banks - time deposits (360d as baseline)
INSERT INTO rates (bank_id, product_type, term_days, rate, source) VALUES
  ('bpi', 'time_deposit', 30, 0.2500, 'manual'),
  ('bpi', 'time_deposit', 90, 0.5000, 'manual'),
  ('bpi', 'time_deposit', 180, 0.7500, 'manual'),
  ('bpi', 'time_deposit', 360, 1.0000, 'manual'),
  ('bdo', 'time_deposit', 30, 0.2500, 'manual'),
  ('bdo', 'time_deposit', 90, 0.3750, 'manual'),
  ('bdo', 'time_deposit', 180, 0.6250, 'manual'),
  ('bdo', 'time_deposit', 360, 0.8750, 'manual'),
  ('metrobank', 'time_deposit', 30, 0.3750, 'manual'),
  ('metrobank', 'time_deposit', 90, 0.5000, 'manual'),
  ('metrobank', 'time_deposit', 180, 0.8750, 'manual'),
  ('metrobank', 'time_deposit', 360, 1.1250, 'manual');

-- Digital banks - savings
INSERT INTO rates (bank_id, product_type, term_days, rate, source) VALUES
  ('maya', 'savings', NULL, 3.5000, 'manual'),
  ('cimb', 'savings', NULL, 2.5000, 'manual'),
  ('tonik', 'savings', NULL, 3.0000, 'manual'),
  ('gotyme', 'savings', NULL, 3.0000, 'manual'),
  ('seabank', 'savings', NULL, 3.0000, 'manual'),
  ('gcash_gsave', 'savings', NULL, 2.6000, 'manual');

-- Digital banks - time deposits
INSERT INTO rates (bank_id, product_type, term_days, rate, source) VALUES
  ('maya', 'time_deposit', 30, 4.0000, 'manual'),
  ('maya', 'time_deposit', 90, 4.5000, 'manual'),
  ('maya', 'time_deposit', 180, 5.0000, 'manual'),
  ('maya', 'time_deposit', 360, 5.5000, 'manual'),
  ('cimb', 'time_deposit', 30, 3.5000, 'manual'),
  ('cimb', 'time_deposit', 90, 4.0000, 'manual'),
  ('cimb', 'time_deposit', 180, 4.5000, 'manual'),
  ('cimb', 'time_deposit', 360, 5.0000, 'manual'),
  ('tonik', 'time_deposit', 30, 4.0000, 'manual'),
  ('tonik', 'time_deposit', 90, 4.5000, 'manual'),
  ('tonik', 'time_deposit', 180, 5.5000, 'manual'),
  ('tonik', 'time_deposit', 360, 6.0000, 'manual'),
  ('gotyme', 'time_deposit', 30, 3.5000, 'manual'),
  ('gotyme', 'time_deposit', 90, 4.0000, 'manual'),
  ('gotyme', 'time_deposit', 180, 4.5000, 'manual'),
  ('gotyme', 'time_deposit', 360, 5.0000, 'manual'),
  ('seabank', 'time_deposit', 30, 3.5000, 'manual'),
  ('seabank', 'time_deposit', 90, 4.0000, 'manual'),
  ('seabank', 'time_deposit', 180, 4.5000, 'manual'),
  ('seabank', 'time_deposit', 360, 5.0000, 'manual');
